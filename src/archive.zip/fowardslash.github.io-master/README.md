![quangSite_Banner](https://user-images.githubusercontent.com/68984861/212021281-318a0a44-f46d-4f51-b871-85175c3ce504.svg)
# quangSite
Tao fix cứng cỡ chữ đó, đánh nhau ko?\
Hobby project that is a mess
# To-do list
1. [ ] Blog page
2. [x] "Linh tinh" Page
3. [ ] More polished mobile interface.
4. [ ] Proper hosting
5. [x] Favicon
6. [ ] ~~Planning on a REVAMP~~ Canceled. Focusing on Moving to Firebase and doing Blog page.
